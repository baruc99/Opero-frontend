"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { getToken, isTokenValid, removeToken } from "@/lib/auth";

export default function AuthProvider({
    children
}: { children: React.ReactNode }) {

    const router = useRouter();

    useEffect(() => {

        const token = getToken();

        if (!token) {
            router.push("/login");
            return;
        }

        if (!isTokenValid(token)) {
            removeToken();
            router.push("/login");
        }

    }, []);

    return children;

}